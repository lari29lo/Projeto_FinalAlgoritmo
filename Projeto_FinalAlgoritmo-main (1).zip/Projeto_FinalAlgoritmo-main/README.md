# Projeto final de Algoritmos e programação

Repositório da Matéria de Algotimo e Programação

Professor(a): Joyce Siqueira
<br/> <br/> Alunos(as): Henrique Moraes Farias               Matrícula UC22200106            Curso: Análise e Desenvolvimento de Sistemas
             <br/> Larissa Lorraine Ferreira Barbosa    Matrícula UC22200367           Curso: Análise e Desenvolvimento de Sistemas
           <<br/>  Stela Sousa Alves                    Matrícula UC22200017          Curso: Ciência da Computação
